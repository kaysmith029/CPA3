
   
import React, { useState } from "react";
import { Button, StyleSheet, Text, TextInput, View } from "react-native";


// const mph2fps = (mph) => mph*5280/3600

const StartSheet = (props) => {
  const [product, setProduct] = useState(props.product);
 
  const [itemsAdded,setItemsAdded] = useState(0)
  const [debugging,setDebugging] = useState(false)
  const [total,setTotal] = useState(0)


  let debugView = ""
  if (debugging) {
    debugView =
      <View>
          <Text> Product: {product} </Text>
         
          <Text> Items Added: {itemsAdded} </Text>
          
      </View>
  }

      return (
  <View style={styles.container}>
    <Text style={styles.header}>

    Simply type in the name of your item and then press the ADD ITEM button to add the items that you bought during your trip!

    </Text>

    <TextInput
          style={styles.textinput}
          placeholder="Product Last Entered:"
          onChangeText={text => {setProduct(text)}}
      />

<Button
          color='red' title='Add Item'
          onPress = {() =>
               setItemsAdded(itemsAdded+1)          }
      />
  
    <Button
        title={(debugging?'hide':'show')+" Item info" }
        color="#00bfff"
        onPress = {() => setDebugging(!debugging)}
        />
        {debugView}
  
  </View>
      );
    }
  const styles = StyleSheet.create ({
    container: {
      flex: 1,
      flexDirection:'column',
      backgroundColor: '#d0f0c0',
      alignItems: 'center',
      justifyContent: 'center',
      border: "none",
      margin:"10px",
      padding:"10px",
    },
    textinput:{
      margin:20,
      fontSize:20
    },
    header: {
      fontSize:40,
      fontWeight: "bold",
      color:'black',
      fontFamily:'Courier New'
      
    },
    rowContainer: {
      flexDirection: 'row',
      alignItems: 'center',
    },
  });

export default StartSheet;